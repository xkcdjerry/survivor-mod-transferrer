import sys
import bpy

def runner():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('-mp', '--model_path')
    argv = sys.argv
    if "--" not in argv:
        argv = []
    else:
        argv = argv[argv.index("--") + 1:]
    args = parser.parse_args(argv)
    model_path = args.model_path

    # Clear default scene
    bpy.ops.object.select_all(action='SELECT')
    bpy.ops.object.delete()

    bpy.ops.import_scene.fbx(filepath=model_path)
    output_path = model_path.replace(".fbx", ".nekomdl_tmp")

    bpy.ops.export_scene.gltf(
        filepath=output_path,
        export_image_format='NONE',
        export_texcoords=True,
        export_normals=True,
        export_tangents=False,
        export_materials="EXPORT",
        export_colors=False,
        export_attributes=False,
        export_cameras=False,
        use_visible=False,
        use_renderable=False,
        export_yup=False,
        export_apply=False,
        export_animations=False,
        export_bake_animation=False,
        export_skins=True,
        export_all_influences=False,
        export_morph=True,
        export_morph_normal=True,
        export_morph_tangent=False,
        export_morph_animation=False,
        export_draco_mesh_compression_enable=False,
    )


if __name__ == "__main__":
    runner()
